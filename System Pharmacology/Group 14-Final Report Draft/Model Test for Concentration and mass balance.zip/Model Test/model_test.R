rm(list = ls())
cat("\014")


library(ggplot2) 
library(R.matlab)
library(gridExtra)

Data_frommat <- readMat("modeltest.mat",header=T) 
df_frommat <- as.data.frame(Data_frommat) 

g1 <- ggplot(df_frommat,aes(x=T.1,y=T.2))+ 
  geom_line(aes(x=T.1,y=T.2,color='1 Tab'),size=1) +
  geom_line(aes(x=T.1,y=T.3,color='2 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.4,color='3 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.5,color='4 Tabs'),size=1) +
  scale_x_continuous("Time (hrs)")+
  scale_y_continuous("[LUM] (nM)")+
  scale_color_manual(name='',values=c('1 Tab'='black','2 Tabs'='blue','3 Tabs'='red','4 Tabs'='green'))+
  ggtitle("Concentration of LUM in blood")

g2 <- ggplot(df_frommat,aes(x=T.1,y=T.6))+ 
  geom_line(aes(x=T.1,y=T.6,color='1 Tab'),size=1) +
  geom_line(aes(x=T.1,y=T.7,color='2 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.8,color='3 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.9,color='4 Tabs'),size=1) +
  scale_x_continuous("Time (hrs)")+
  scale_y_continuous("[ARM] (nM)")+
  scale_color_manual(name='',values=c('1 Tab'='black','2 Tabs'='blue','3 Tabs'='red','4 Tabs'='green'))+
  ggtitle("Concentration of ARM in blood")

g3 <- ggplot(df_frommat,aes(x=T.1,y=T.10))+ 
  geom_line(aes(x=T.1,y=T.10,color='1 Tab'),size=1) +
  geom_line(aes(x=T.1,y=T.11,color='2 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.12,color='3 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.13,color='4 Tabs'),size=1) +
  scale_x_continuous("Time (hrs)")+
  scale_y_continuous("[DHA] (nM)")+
  scale_color_manual(name='',values=c('1 Tab'='black','2 Tabs'='blue','3 Tabs'='red','4 Tabs'='green'))+
  ggtitle("Concentration of DHA in blood")

g4 <- ggplot(df_frommat,aes(x=T.1,y=T.14))+ 
  geom_line(aes(x=T.1,y=T.14,color='1 Tab'),size=1) +
  geom_line(aes(x=T.1,y=T.15,color='2 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.16,color='3 Tabs'),size=1) +
  geom_line(aes(x=T.1,y=T.17,color='4 Tabs'),size=1) +
  scale_x_continuous("Time (hrs)")+
  scale_y_continuous("[parasite] (log10(1/uL of blood))")+
  scale_color_manual(name='',values=c('1 Tab'='black','2 Tabs'='blue','3 Tabs'='red','4 Tabs'='green'))+
  ggtitle("Concentration of LUM in blood")

out <- grid.arrange(g1,g2,g3,g4,ncol=1)
  
  
