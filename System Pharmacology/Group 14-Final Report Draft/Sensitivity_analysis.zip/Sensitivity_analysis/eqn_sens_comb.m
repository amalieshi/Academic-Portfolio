function dydt = eqn_sens_comb(t,y,p)
kA=p(1);
kcl=p(2);
V1=p(3);
V2=p(4);
V3=p(5);
ka=p(6);
kcldha=p(7);
Q=p(8);
Vo=p(9);
Varmc=p(10);
Varmp=p(11);
Vdha=p(12);
Vc=p(13);
Pinit=p(14);
VPT=p(15);
MTT=p(16);
REPL=p(17);
s=p(18);
theta1 = p(19);
theta2 = p(20);
m = p(21);
tab = p(22);

m=43.91;
occ =1;
kclarm=theta1*(1+(theta2*(occ-1)))*m; % oral clearance

dydt = zeros(12,1);   
%LUM
dydt(1)=-kA*y(1); % absorption
dydt(2)=(V1/V2)*kA*y(1)-y(2)*(kcl/V2); %main
dydt(3)=y(2)*(kcl/V2)*(V2/V3); %peripheral
%ARM & DHA
dydt(4)=-ka*y(4); % absorption
dydt(5)=(Vo/Varmc)*ka*y(4)-y(5)*(Q/Varmc)-y(5)*(kclarm/Varmc)+y(6)*(Q/Varmp)*(Varmp/Varmc); % Central
dydt(6)=y(5)*(Q/Varmc)*(Varmc/Varmp)-y(6)*(Q/Varmp); % Peripheral
dydt(7)=y(5)*(kclarm/Varmc)*(Varmc/Vdha)-y(7)*(kcldha/Vdha); % Central DHA
dydt(8)=y(7)*(kcldha/Vdha)*(Vdha/Vc);% Clearance 3
%Parasite
dydt(9)=Pinit+(y(12)*REPL/(MTT-VPT))-(y(9)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7))))); %P_TR
dydt(10)=(y(9)*(3/VPT))-(y(10)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7))))); %SR
dydt(11)=(y(10)*(3/VPT))-(y(11)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7))))); %LR
dydt(12)=(y(11)*(3/VPT))-(y(12)*((s*log10(1+y(5)+y(6)))+(s*log10(1+y(7)))+(1/(MTT-VPT)))); %MT
end