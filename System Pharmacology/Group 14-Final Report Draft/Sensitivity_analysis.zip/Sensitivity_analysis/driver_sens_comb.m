function driver_sens_comb(m)
% Loading Parameters

if m >= 5 && m <= 14
    tab=1;
elseif m >= 15 && m <= 24
    tab=2;
elseif m >= 25 && m <= 34
    tab=3;
elseif m >=35
    tab=4;
end

DLUM=120*tab/1000*(10^9)/298.379; %nmol
DARM=20*tab/1000*(10^9)/298.379;

% Population pharmacokinetic parameters of ARM & DHA
theta1=2.6;
theta2=0.57;
occ=1;

kA=.82;
kcl=.077*m;
V1=8.9*m;
V2=8.9*m;
V3=8.9*m;
ka=1;
kclarm=theta1*(1+(theta2*(occ-1)))*m; % oral clearance
kcldha=6.8*m;  % Oral metabolite clearance
Q=1.4*m; % Intercompartment clearance
Vo=1;
Varmc=5.2*m; % Oral volume of distribution of the central compartment
Varmp=41.4*m;  % Oral volume of distribution
Vdha=3.7*m; % volume metabolite volume of distribution.
Vc=1;
Pinit=1;
VPT=15.5;
MTT=48.5;
REPL=4;
s=.073;

p0=[kA,kcl,V1,V2,V3,ka,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s,theta1,theta2,m,tab];
Sens1 = NaN(1,length(p0));
Sens2 = Sens1;
Sens3 = Sens1;
Sens4 = Sens1;
for index = 1:length(p0)
    OutputVar = index;
    ParamDelta = 0.05; % test sensitivity to a 5% change
    % BASE CASE
    [outAUC1_0,outAUC2_0,outAUC3_0,outParamin_0] = main_sens_comb(p0);
%    t = t0;
%    y = y0;
    p = p0;
    %add the 5% change
    if index==21 % mass + 5% change
        m0 = m*(1.0+ParamDelta);
        kA=.82;
        kcl=.077*m0;
        V1=8.9*m0;
        V2=8.9*m0;
        V3=8.9*m0;
        ka=1;
        kclarm=theta1*(1+(theta2*(occ-1)))*m0; % oral clearance
        kcldha=6.8*m0;  % Oral metabolite clearance
        Q=1.4*m0; % Intercompartment clearance
        Vo=1;
        Varmc=5.2*m0; % Oral volume of distribution of the central compartment
        Varmp=41.4*m0;  % Oral volume of distribution
        Vdha=3.7*m0; % volume metabolite volume of distribution.
        Vc=1;
        Pinit=1;
        VPT=15.5;
        MTT=48.5;
        REPL=4;
        s=.073;
        p=[kA,kcl,V1,V2,V3,ka,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s,theta1,theta2,m0,tab]; 
        
    else  % other parameters change   
        p(index)=p0(index)*(1.0+ParamDelta);
    end
    
    [outAUC1,outAUC2,outAUC3,outParamin,massbalLUM,massbalARM,T1,Y1] = main_sens_comb(p);
    Sens1(1,index) = ((outAUC1-outAUC1_0)/outAUC1_0)/((p(index)-p0(index))/p0(index));
    Sens2(1,index) = ((outAUC2-outAUC2_0)/outAUC2_0)/((p(index)-p0(index))/p0(index));
    Sens3(1,index) = ((outAUC3-outAUC3_0)/outAUC3_0)/((p(index)-p0(index))/p0(index));
    Sens4(1,index) = ((outParamin-outParamin_0)/outParamin_0)/((p(index)-p0(index))/p0(index));
end
figure(1)
subplot(2,1,1)
plot(massbalLUM)
subplot(2,1,2)
plot(massbalARM)

LUM = Sens1(1,[1:5,21,22])';
ARM = Sens2(1,[6:13,19,20,21,22])';
DHA = Sens3(1,[6:13,19,20,21,22])';
Parasite = Sens4(1,6:22)';
save LUM.mat LUM
save ARM.mat ARM
save DHA.mat DHA
save Parasite.mat Parasite



