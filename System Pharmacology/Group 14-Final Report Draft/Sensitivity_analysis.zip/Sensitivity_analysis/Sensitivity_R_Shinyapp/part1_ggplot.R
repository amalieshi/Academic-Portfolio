# install.packages("rstudioapi") # run this if it's your first time using it to install
library(rstudioapi) # load it
# the following line is for getting the path of your current open file
current_path <- getActiveDocumentContext()$path 
# The next line set the working directory to the relevant one:
setwd(dirname(current_path))
# you can make sure you are in the right directory

# Visualization (R code)
# Load relevant libraries.
library(R.matlab)
library(plotly)
library(ggplot2) 
library(R.matlab)
library(reshape2)
library(plyr)
library(gridExtra)
library(data.table)
require(shiny)

#Load Data
# 5kg
Data_frommat <- readMat("weight_5/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_5 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_5/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM_5 <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_5/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA_5 <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM_5,DHA_5)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_5 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_5/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_5 <- melt(Parasite,id.vars='Outputs')

# # 15kg
Data_frommat <- readMat("weight_15/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_15 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_15/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_15/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM,DHA)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_15 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_15/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_15 <- melt(Parasite,id.vars='Outputs')

#20kg
Data_frommat <- readMat("weight_20/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_20 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_20/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_20/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM,DHA)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_20 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_20/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_20 <- melt(Parasite,id.vars='Outputs')

#25kg
Data_frommat <- readMat("weight_25/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_25 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_25/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_25/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM,DHA)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_25 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_25/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_25 <- melt(Parasite,id.vars='Outputs')

# 30kg
Data_frommat <- readMat("weight_30/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_30 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_30/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_30/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM,DHA)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_30 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_30/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_30 <- melt(Parasite,id.vars='Outputs')

#43.91kg
Data_frommat <- readMat("weight_4391/LUM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
LUM <- setNames(df_frommat, c("LUM AUC"))
LUM$Outputs <- c("kA","kcl","V1","V2","V3","m","tab");
LUM_4391 <- melt(LUM,id.vars='Outputs')

Data_frommat <- readMat("weight_4391/ARM.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
ARM <- setNames(df_frommat, c("ARM AUC"))

Data_frommat <- readMat("weight_4391/DHA.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
DHA <- setNames(df_frommat, c("DHA AUC"))

ARMDHA<-cbind(ARM,DHA)
ARMDHA$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","theta1","theta2","m","tab");
ARMDHA_4391 <- melt(ARMDHA,id.vars='Outputs')

Data_frommat <- readMat("weight_4391/Parasite.mat",header=T) # from mat file
df_frommat <- data.frame(Data_frommat)
Parasite <- setNames(df_frommat, c("Parasite Ctrough"))
Parasite$Outputs <- c("ka","kcldha","Q","Vo","Varmc","Varmp","Vdha","Vc","Pinit","VPT","MTT","REPL","s","theta1","theta2","m","tab");
Parasite_4391 <- melt(Parasite,id.vars='Outputs')




g1 <- ggplot(LUM_5,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed()+ # Locks x & y scales together, making each tile a square (sometimes nice)
g2 <- ggplot(LUM_15,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
g3 <- ggplot(LUM_20,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
g4 <- ggplot(LUM_25,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
g5 <- ggplot(LUM_30,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
g6 <- ggplot(LUM_4391,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=0,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)

#second
p1 <- ggplot(ARMDHA_5,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
p2 <- ggplot(ARMDHA_15,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
p3 <- ggplot(ARMDHA_20,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
p4 <- ggplot(ARMDHA_25,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
p5 <- ggplot(ARMDHA_30,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.1,1.1),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
p6 <- ggplot(ARMDHA_4391,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkred',high='darkgreen',mid='white',midpoint=0,limit=c(-1.2,1.2),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)

# third
l1 <- ggplot(Parasite_5,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
l2 <- ggplot(Parasite_15,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
l3 <- ggplot(Parasite_20,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
l4 <- ggplot(Parasite_25,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
l5 <- ggplot(Parasite_30,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)
l6 <- ggplot(Parasite_4391,aes(x=Outputs,y=variable,fill=value))+geom_tile(color='black')+ # Color describes the lines between each tile. I chose black, so each tile is outlined (so white tiles are distinct from background)
  xlab('') + ylab('') + theme_minimal()+ # Minimal theme removes the gray background, making a cleaner heatmap.
  scale_fill_gradient2(low='darkgreen',high='darkred',mid='white',midpoint=0,limit=c(-3.5,3.5),name='Sensitivity')+
  theme(axis.text.x =element_text(angle=90,vjust=1,hjust=1),text=element_text(size=12))+
  coord_fixed() # Locks x & y scales together, making each tile a square (sometimes nice)

out <- grid.arrange(g1,p1,l1,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_5.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).

out <- grid.arrange(g2,p2,l2,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_15.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).

out <- grid.arrange(g3,p3,l3,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_20.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).

out <- grid.arrange(g4,p4,l4,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_25.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).

out <- grid.arrange(g5,p5,l5,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_30.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).

out <- grid.arrange(g6,p6,l6,nrow =3, ncol=1)
#out <- grid.arrange(g1,p1,l1,nrow=3)
ggsave(file="sensitivity_4391.png",plot=out,width=12,height=8) # Save the figure, specifying the dimensions (in inches).
