function dydt = tissue_combinedeqn(t,y,p)

kA=p(1);
kcl=p(2);
V1=p(3);
V2=p(4);
V3=p(5);
ka=p(6);
kclarm=p(7);
kcldha=p(8);
Q=p(9);
Vo=p(10);
Varmc=p(11);
Varmp=p(12);
Vdha=p(13);
Vc=p(14);
Pinit=p(15);
VPT=p(16);
MTT=p(17);
REPL=p(18);
s=p(19);


dydt = zeros(12,1);   

dydt(1)=-kA*y(1);
dydt(2)=(V1/V2)*kA*y(1)-y(2)*(kcl/V2);
dydt(3)=y(2)*(kcl/V2)*(V2/V3);

dydt(4)=-ka*y(4);
dydt(5)=(Vo/Varmc)*ka*y(4)-y(5)*(Q/Varmc)-y(5)*(kclarm/Varmc)+y(6)*(Q/Varmp)*(Varmp/Varmc);
dydt(6)=y(5)*(Q/Varmc)*(Varmc/Varmp)-y(6)*(Q/Varmp);
dydt(7)=y(5)*(kclarm/Varmc)*(Varmc/Vdha)-y(7)*(kcldha/Vdha);
dydt(8)=y(7)*(kcldha/Vdha)*(Vdha/Vc);

dydt(9)=Pinit+(y(12)*REPL/(MTT-VPT))-(y(9)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7)))));
dydt(10)=(y(9)*(3/VPT))-(y(10)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7)))));
dydt(11)=(y(10)*(3/VPT))-(y(11)*((3/VPT)+(s*log10(1+y(5)+y(6)))+(s*log10(1+y(7)))));
dydt(12)=(y(11)*(3/VPT))-(y(12)*((s*log10(1+y(5)+y(6)))+(s*log10(1+y(7)))+(1/(MTT-VPT))));