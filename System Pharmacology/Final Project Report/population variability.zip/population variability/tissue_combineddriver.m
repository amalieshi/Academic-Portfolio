clear all

%%%%%%%%%%%%%%%%%%%%%%for weight%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ma = 25.46;
mb = 96.8;
mc = 0;
me=1;
m = ma.*randn(100,1) + mb;
for i =1 :1:100
if m(i,1)<0 || m(i,1)==0
mc=mc+1;
end
end
if mc >0
md = ma.*randn(mc,1) + mb;
for i =1 :1:100
if m(i,1)<0 || m(i,1)==0
m(i,1)=md(me,1);
me=me+1;
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% for tab%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tab=0;
for i=1:100
    m(i,1) = m(i,1)/2.20462;
if m(i,1) >= 5 && m(i,1) <= 14
    tab(i,1)=1;
elseif m(i,1) > 14 && m(i,1) <= 24
    tab(i,1)=2;
elseif m(i,1) >24 && m(i,1) <= 34
    tab(i,1)=3;
elseif m(i,1) >34
    tab(i,1)=4;
end
end
for i=1:100
DLUM(i,1)=120*tab(i,1)/1000*(10^9)/298.379;
DARM(i,1)=20*tab(i,1)/1000*(10^9)/298.379;
end
%%%%%%%%%%%%%%%%%%%%%% for parameter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
theta1=2.6;
theta2=.57;
occ=1;
kcl=.077*m;
V1=8.9*m;
V2=8.9*m;
V3=8.9*m;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
kcldha=6.8*m;
Q=1.4*m;
Varmc=5.2*m;
Varmp=41.4*m;
Vdha=3.7*m;
for i = 1:100
Vo(i,1)=1;
ka(i,1)=1;
kA(i,1)=.82;
Vc(i,1)=1;
Pinit(i,1)=1;
VPT(i,1)=15.5;
MTT(i,1)=48.5;
REPL(i,1)=4;
s(i,1)=.073;
end
%%%%%%%%%%%%%%%%%%%% term 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
tlen=8;
for i = 1:100
y0(i,:)=[DLUM(i,1)/V1(i,1) 0 0 DARM(i,1)/Vo(i,1) 0 0 0 0 10771 8952.9 7441.4 20685]; 
[result1(i,:),result2(i,:),result3(i,:),result4(i,:),...
    result5(i,:),result6(i,:),result7(i,:),result8(i,:),...
    result9(i,:),result10(i,:),result11(i,:),result12(i,:),result13(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
end

% 
% TotalD1_1 = Y1(:,1)*V1;
% TotalD2_1 = Y1(:,2)*V2;
% TotalD3_1 = Y1(:,3)*V3;
% massbalLUM=-TotalD1_1-TotalD2_1-TotalD3_1+DLUM;
% 
% 
% TotalD4_1 = Y1(:,4)*Vo;
% TotalD5_1 = Y1(:,5)*Varmc;
% TotalD6_1 = Y1(:,6)*Varmp;
% TotalD7_1 = Y1(:,7)*Vdha;
% TotalD8_1 = Y1(:,8)*Vc;
% massbalARM=-TotalD4_1-TotalD5_1-TotalD6_1-TotalD7_1-TotalD8_1+DARM;

%%%%%%%%%%%%%%%%term 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 16;
 for i= 1:100
 y0(i,:)=[result1(i,end)+DLUM(i,1)/V1(i,1),result2(i,end),result3(i,end),result4(i,end)+DARM(i,1)/Vo(i,1),result5(i,end),result6(i,end),...
    result7(i,end),result8(i,end),result9(i,end),result10(i,end),result11(i,end),result12(i,end)];
[r21(i,:),r22(i,:),r23(i,:),r24(i,:),...
    r25(i,:),r26(i,:),r27(i,:),r28(i,:),...
    r29(i,:),r210(i,:),r211(i,:),r212(i,:),r213(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end
% TotalD1_2 = Y2(:,1)*V1;
% TotalD2_2 = Y2(:,2)*V2;
% TotalD3_2 = Y2(:,3)*V3;
% 
% TotalD4_2 = Y2(:,4)*Vo;
% TotalD5_2 = Y2(:,5)*Varmc;
% TotalD6_2 = Y2(:,6)*Varmp;
% TotalD7_2 = Y2(:,7)*Vdha;
% TotalD8_2 = Y2(:,8)*Vc;
% 
% Y1= vertcat(Y1([1:end-1],:),Y2);
% T2=T2+8;
% T1= vertcat(T1([1:end-1]),T2);
% 
% massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_2-TotalD2_2-TotalD3_2+(DLUM*2)));
% massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_2-TotalD5_2-TotalD6_2-TotalD7_2-TotalD8_2+(DARM*2)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% term3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r21(i,end)+DLUM(i,1)/V1(i,1),r22(i,end),r23(i,end),r24(i,end)+DARM(i,1)/Vo(i,1),r25(i,end),r26(i,end),...
    r27(i,end),r28(i,end),r29(i,end),r210(i,end),r211(i,end),r212(i,end)];
[r31(i,:),r32(i,:),r33(i,:),r34(i,:),...
    r35(i,:),r36(i,:),r37(i,:),r38(i,:),...
    r39(i,:),r310(i,:),r311(i,:),r312(i,:),r313(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end

 % TotalD1_3 = Y3(:,1)*V1;
% TotalD2_3 = Y3(:,2)*V2;
% TotalD3_3 = Y3(:,3)*V3;
% 
% TotalD4_3 = Y3(:,4)*Vo;
% TotalD5_3 = Y3(:,5)*Varmc;
% TotalD6_3 = Y3(:,6)*Varmp;
% TotalD7_3 = Y3(:,7)*Vdha;
% TotalD8_3 = Y3(:,8)*Vc;
% 
% Y1= vertcat(Y1([1:end-1],:),Y3);
% T3=T3+24;
% T1= vertcat(T1([1:end-1]),T3);
% 
% massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_3-TotalD2_3-TotalD3_3+(DLUM*3)));
% massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_3-TotalD5_3-TotalD6_3-TotalD7_3-TotalD8_3+(DARM*3)));

%%%%%%%%%%%%%%%%%%%term four%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r31(i,end)+DLUM(i,1)/V1(i,1),r32(i,end),r33(i,end),r34(i,end)+DARM(i,1)/Vo(i,1),r35(i,end),r36(i,end),...
    r37(i,end),r38(i,end),r39(i,end),r310(i,end),r311(i,end),r312(i,end)];
[r41(i,:),r42(i,:),r43(i,:),r44(i,:),...
    r45(i,:),r46(i,:),r47(i,:),r48(i,:),...
    r49(i,:),r410(i,:),r411(i,:),r412(i,:),r413(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end

 % TotalD1_4 = Y4(:,1)*V1;
% TotalD2_4 = Y4(:,2)*V2;
% TotalD3_4 = Y4(:,3)*V3;
% 
% TotalD4_4 = Y4(:,4)*Vo;
% TotalD5_4 = Y4(:,5)*Varmc;
% TotalD6_4 = Y4(:,6)*Varmp;
% TotalD7_4 = Y4(:,7)*Vdha;
% TotalD8_4 = Y4(:,8)*Vc;
% 
% Y1= vertcat(Y1([1:end-1],:),Y4);
% T4=T4+36;
% T1= vertcat(T1([1:end-1]),T4);
% 
% massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_4-TotalD2_4-TotalD3_4+(DLUM*4)));
% massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_4-TotalD5_4-TotalD6_4-TotalD7_4-TotalD8_4+(DARM*4)));
%%%%%%%%%%%%%%%%%%%%% term 5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r41(i,end)+DLUM(i,1)/V1(i,1),r42(i,end),r43(i,end),r44(i,end)+DARM(i,1)/Vo(i,1),r45(i,end),r46(i,end),...
    r47(i,end),r48(i,end),r49(i,end),r410(i,end),r411(i,end),r412(i,end)];
[r51(i,:),r52(i,:),r53(i,:),r54(i,:),...
    r55(i,:),r56(i,:),r57(i,:),r58(i,:),...
    r59(i,:),r510(i,:),r511(i,:),r512(i,:),r513(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end


% 
% TotalD1_5 = Y5(:,1)*V1;
% TotalD2_5 = Y5(:,2)*V2;
% TotalD3_5 = Y5(:,3)*V3;
% 
% TotalD4_5 = Y5(:,4)*Vo;
% TotalD5_5 = Y5(:,5)*Varmc;
% TotalD6_5 = Y5(:,6)*Varmp;
% TotalD7_5 = Y5(:,7)*Vdha;
% TotalD8_5 = Y5(:,8)*Vc;
% 
% Y1= vertcat(Y1([1:end-1],:),Y5);
% T5=T5+48;
% T1= vertcat(T1([1:end-1]),T5);
% 
% massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_5-TotalD2_5-TotalD3_5+(DLUM*5)));
% massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_5-TotalD5_5-TotalD6_5-TotalD7_5-TotalD8_5+(DARM*5)));
% 


%%%%%%%%%%%%%%%%%%%%% term 6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r51(i,end)+DLUM(i,1)/V1(i,1),r52(i,end),r53(i,end),r54(i,end)+DARM(i,1)/Vo(i,1),r55(i,end),r56(i,end),...
    r57(i,end),r58(i,end),r59(i,end),r510(i,end),r511(i,end),r512(i,end)];
[r61(i,:),r62(i,:),r63(i,:),r64(i,:),...
    r65(i,:),r66(i,:),r67(i,:),r68(i,:),...
    r69(i,:),r610(i,:),r611(i,:),r612(i,:),r613(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end

% 
% TotalD1_6 = Y6(:,1)*V1;
% TotalD2_6 = Y6(:,2)*V2;
% TotalD3_6 = Y6(:,3)*V3;
% 
% TotalD4_6 = Y6(:,4)*Vo;
% TotalD5_6 = Y6(:,5)*Varmc;
% TotalD6_6 = Y6(:,6)*Varmp;
% TotalD7_6 = Y6(:,7)*Vdha;
% TotalD8_6 = Y6(:,8)*Vc;
% 
% Y1= vertcat(Y1([1:end-1],:),Y6);
% T6=T6+60;
% T1= vertcat(T1([1:end-1]),T6);
% 
% massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_6-TotalD2_6-TotalD3_6+(DLUM*6)));
% massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_6-TotalD5_6-TotalD6_6-TotalD7_6-TotalD8_6+(DARM*6)));
% 
t = 0;
for i = 1:7206
    t(i,1) =  i*0.01;
end

rLUM = cat(2,result2,r22,r32,r42,r52,r62);
rARM1 = cat(2,result5,r25,r35,r45,r55,r65);
rARM2 = cat(2,result6,r26,r36,r46,r56,r66);
rDHA = cat(2,result7,r27,r37,r47,r57,r67);

for i = 1:100
    AUCLUM(i,1) = trapz(t,rLUM(i,:));
    AUCARM(i,1) = trapz(t,rARM1(i,:))+trapz(t,rARM2(i,:));
    AUCDHA(i,1) = trapz(t,rDHA(i,:));
    CtrLUM(i,1) = rLUM(i,end);
    CtrARM(i,1) = rARM1(i,end)+rARM2(i,end);
    CtrDHA(i,1) = rDHA(i,end);
end
    

    
    




figure(1)
plot(t,rLUM(50,:))
figure(2)
plot(t,rARM1(50,:)+rARM2(50,:))
hold on
plot(t,rDHA(50,:))
% 
% figure(3)
% plot(T1,log10(Y1(:,12)))
% 
% 
% 
% % figure(4)
% % plot(T1,massbalLUM)
% % 
% % figure(5)
% % plot(T1,massbalARM)
% 
