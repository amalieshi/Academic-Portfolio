library(shiny)
library(plotly)
library(ggplot2) 
library(R.matlab)
library(reshape2)
library(plyr)
library(rstudioapi)
library(gridExtra)
library(data.table)
require(shiny)
# Import data: this is outside the reactive statements because it only needs
# to run once, when the app is opened.
sub<- 1:100
df_sub<-as.data.frame(sub)

fa <- readMat("vM.mat",header=T) # from mat file
df_fa <- as.data.frame(fa) # Convert .mat data into a data frame.
fb <- readMat("vV2.mat",header=T) # from mat file
df_fb <- as.data.frame(fb) # Convert .mat data into a data frame.
fc <- readMat("vV2w.mat",header=T) # from mat file
df_fc <- as.data.frame(fc) # Convert .mat data into a data frame.
fd <- readMat("vVarmc.mat",header=T) # from mat file
df_fd <- as.data.frame(fd) # Convert .mat data into a data frame.
fe <- readMat("vVarmw.mat",header=T) # from mat file
df_fe <- as.data.frame(fe) # Convert .mat data into a data frame.

df_LUMAUC1 <- cbind.data.frame(df_fa$AUCLUM,df_fb$AUCLUM,df_fc$AUCLUM,df_fd$AUCLUM,df_fe$AUCLUM,df_sub)
colnames(df_LUMAUC1)[colnames(df_LUMAUC1)=="df_fa$AUCLUM"] <- "Weight"
colnames(df_LUMAUC1)[colnames(df_LUMAUC1)=="df_fb$AUCLUM"] <- "V-LUM"
colnames(df_LUMAUC1)[colnames(df_LUMAUC1)=="df_fc$AUCLUM"] <- "V-LUM_&_Weight"
colnames(df_LUMAUC1)[colnames(df_LUMAUC1)=="df_fd$AUCLUM"] <- "V-ARM"
colnames(df_LUMAUC1)[colnames(df_LUMAUC1)=="df_fe$AUCLUM"] <- "V-ARM_&_Weight"

df_ARMAUC1 <- cbind.data.frame(df_fa$AUCARM,df_fb$AUCARM,df_fc$AUCARM,df_fd$AUCARM,df_fe$AUCARM,df_sub)
colnames(df_ARMAUC1)[colnames(df_ARMAUC1)=="df_fa$AUCARM"] <- "Weight"
colnames(df_ARMAUC1)[colnames(df_ARMAUC1)=="df_fb$AUCARM"] <- "V-LUM"
colnames(df_ARMAUC1)[colnames(df_ARMAUC1)=="df_fc$AUCARM"] <- "V-LUM_&_Weight"
colnames(df_ARMAUC1)[colnames(df_ARMAUC1)=="df_fd$AUCARM"] <- "V-ARM"
colnames(df_ARMAUC1)[colnames(df_ARMAUC1)=="df_fe$AUCARM"] <- "V-ARM_&_Weight"

df_DHAAUC1 <- cbind.data.frame(df_fa$AUCDHA,df_fb$AUCDHA,df_fc$AUCDHA,df_fd$AUCDHA,df_fe$AUCDHA,df_sub)
colnames(df_DHAAUC1)[colnames(df_DHAAUC1)=="df_fa$AUCDHA"] <- "Weight"
colnames(df_DHAAUC1)[colnames(df_DHAAUC1)=="df_fb$AUCDHA"] <- "V-LUM"
colnames(df_DHAAUC1)[colnames(df_DHAAUC1)=="df_fc$AUCDHA"] <- "V-LUM_&_Weight"
colnames(df_DHAAUC1)[colnames(df_DHAAUC1)=="df_fd$AUCDHA"] <- "V-ARM"
colnames(df_DHAAUC1)[colnames(df_DHAAUC1)=="df_fe$AUCDHA"] <- "V-ARM_&_Weight"

df_LUMCTR1 <- cbind.data.frame(df_fa$CtrLUM,df_fb$CtrLUM,df_fc$CtrLUM,df_fd$CtrLUM,df_fe$CtrLUM,df_sub)
colnames(df_LUMCTR1)[colnames(df_LUMCTR1)=="df_fa$CtrLUM"] <- "Weight"
colnames(df_LUMCTR1)[colnames(df_LUMCTR1)=="df_fb$CtrLUM"] <- "V-LUM"
colnames(df_LUMCTR1)[colnames(df_LUMCTR1)=="df_fc$CtrLUM"] <- "V-LUM_&_Weight"
colnames(df_LUMCTR1)[colnames(df_LUMCTR1)=="df_fd$CtrLUM"] <- "V-ARM"
colnames(df_LUMCTR1)[colnames(df_LUMCTR1)=="df_fe$CtrLUM"] <- "V-ARM_&_Weight"

df_ARMCTR1 <- cbind.data.frame(df_fa$CtrARM,df_fb$CtrARM,df_fc$CtrARM,df_fd$CtrARM,df_fe$CtrARM,df_sub)
colnames(df_ARMCTR1)[colnames(df_ARMCTR1)=="df_fa$CtrARM"] <- "Weight"
colnames(df_ARMCTR1)[colnames(df_ARMCTR1)=="df_fb$CtrARM"] <- "V-LUM"
colnames(df_ARMCTR1)[colnames(df_ARMCTR1)=="df_fc$CtrARM"] <- "V-LUM_&_Weight"
colnames(df_ARMCTR1)[colnames(df_ARMCTR1)=="df_fd$CtrARM"] <- "V-ARM"
colnames(df_ARMCTR1)[colnames(df_ARMCTR1)=="df_fe$CtrARM"] <- "V-ARM_&_Weight"

df_DHACTR1 <- cbind.data.frame(df_fa$CtrDHA,df_fb$CtrDHA,df_fc$CtrDHA,df_fd$CtrDHA,df_fe$CtrDHA,df_sub)
colnames(df_DHACTR1)[colnames(df_DHACTR1)=="df_fa$CtrDHA"] <- "Weight"
colnames(df_DHACTR1)[colnames(df_DHACTR1)=="df_fb$CtrDHA"] <- "V-LUM"
colnames(df_DHACTR1)[colnames(df_DHACTR1)=="df_fc$CtrDHA"] <- "V-LUM_&_Weight"
colnames(df_DHACTR1)[colnames(df_DHACTR1)=="df_fd$CtrDHA"] <- "V-ARM"
colnames(df_DHACTR1)[colnames(df_DHACTR1)=="df_fe$CtrDHA"] <- "V-ARM_&_Weight"

df_minp1 <- cbind.data.frame(df_fa$minp,df_fb$minp,df_fc$minp,df_fd$minp,df_fe$minp,df_sub)
colnames(df_minp1)[colnames(df_minp1)=="df_fa$minp"] <- "Weight"
colnames(df_minp1)[colnames(df_minp1)=="df_fb$minp"] <- "V-LUM"
colnames(df_minp1)[colnames(df_minp1)=="df_fc$minp"] <- "V-LUM_&_Weight"
colnames(df_minp1)[colnames(df_minp1)=="df_fd$minp"] <- "V-ARM"
colnames(df_minp1)[colnames(df_minp1)=="df_fe$minp"] <- "V-ARM_&_Weight"

boxmeltLUMAUC <- melt(df_LUMAUC1,id.vars="sub")
boxmeltARMAUC <- melt(df_ARMAUC1,id.vars="sub")
boxmeltDHAAUC <- melt(df_DHAAUC1,id.vars="sub")
boxmeltLUMCTR <- melt(df_LUMCTR1,id.vars="sub")
boxmeltARMCTR <- melt(df_ARMCTR1,id.vars="sub")
boxmeltDHACTR <- melt(df_DHACTR1,id.vars="sub")
boxmeltminp <- melt(df_minp1,id.vars="sub")

ui <- fluidPage(
  
  fluidRow(
    column(12,plotlyOutput("AUCLUM",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="AUCLUM1", label = ("Y axis for AUC of LUM"), min = 0, max = 3000000, value = c(0,3000000))
  ),
  
  hr(),  
  
  fluidRow(
    column(12,plotlyOutput("AUCARM",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="AUCARM1", label = ("Y axis for AUC of ARM"), min = 0, max = 200000, value = c(0,200000))
  ),
  
  hr(), 
  
  fluidRow(
    column(12,plotlyOutput("AUCDHA",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="AUCDHA1", label = ("Y axis for AUC of DHA"), min = 0, max = 20000, value = c(0,20000))
  ),
  
  hr(), 
  
  fluidRow(
    column(12,plotlyOutput("CtroughLUM",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="CtroughLUM1", label = ("Y axis for Ctrough of LUM"), min = 0, max = 20000, value = c(0,20000))
  ),
  
  hr(), 
  
  fluidRow(
    column(12,plotlyOutput("CtroughARM",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="CtroughARM1", label = ("Y axis for Ctrough of ARM"), min = 0, max = 20000, value = c(0,20000))
  ),
  
  hr(), 
  
  fluidRow(
    column(12,plotlyOutput("CtroughDHA",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="CtroughDHA1", label = ("Y axis for Ctrough of DHA"), min = 0, max = 20000, value = c(0,20000))
  ),
  
  hr(), 
  
  fluidRow(
    column(12,plotlyOutput("minparasite",height=500,width=1000))
  ),
  
  wellPanel(
    sliderInput(inputId="minparasite1", label = ("Y axis for Ctrough of Parasite"), min = -1.7, max = -.9, value = c(-1.7,-.9))
  )
  
  )


# Define server logic required to draw a histogram
server<- function(input, output) {
  output$AUCLUM <- renderPlotly({
    f1 <- input$AUCLUM1
    
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g1 <- ggplot(boxmeltLUMAUC,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of LUM AUC of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('AUC') + ylim(f1[1],f1[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
    
    P<-ggplotly(g1) 
  })
  
  
  output$AUCARM <- renderPlotly({
    f2 <- input$AUCARM1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g2 <- ggplot(boxmeltARMAUC,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of ARM AUC of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('AUC') + ylim(f2[1],f2[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
   
    P<-ggplotly(g2) 
  })
  
  output$AUCDHA <- renderPlotly({
    f3 <- input$AUCDHA1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g3 <- ggplot(boxmeltDHAAUC,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of DHA AUC of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('AUC') + ylim(f3[1],f3[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
    
    P<-ggplotly(g3) 
  })
  
  output$CtroughLUM <- renderPlotly({
    f4 <- input$CtroughLUM1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g4 <- ggplot(boxmeltLUMCTR,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of LUM Ctrough of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('Ctrough') + ylim(f4[1],f4[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
    
    P<-ggplotly(g4) 
  })
  
  output$CtroughARM <- renderPlotly({
    f5 <- input$CtroughARM1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g5 <- ggplot(boxmeltARMCTR,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of ARM Ctrough of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('Ctrough') + ylim(f5[1],f5[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
  
    
    P<-ggplotly(g5) 
  })
  
  output$CtroughDHA <- renderPlotly({
    f6 <- input$CtroughDHA1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g6 <- ggplot(boxmeltDHACTR,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of DHA Ctrough of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('Ctrough') + ylim(f6[1],f6[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
    P<-ggplotly(g6) 
  })
  
  output$minparasite <- renderPlotly({
    f7 <- input$minparasite1
    
    ord <- c("Weight", "V-LUM","V-LUM&weight","V-ARM","V-ARM&weight")
    g7 <- ggplot(boxmeltminp,aes(x=variable,y=value,fill=variable)) + 
      geom_boxplot() +ggtitle("Box Plots of Parasite Ctrough of Random Populations")+
      theme(text=element_text(size=20),axis.text.x=element_text(angle=90,hjust=1)) +
      scale_x_discrete(labels=ord)+
      ylab('Ctrough') + ylim(f7[1],f7[2])+
      theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank())+
      guides(fill=FALSE)
    
    
    P<-ggplotly(g7) 
  })
}
shinyApp(ui=ui,server = server)