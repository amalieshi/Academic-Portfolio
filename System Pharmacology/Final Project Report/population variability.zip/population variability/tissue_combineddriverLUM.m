clear all

%%%%%%%%%%%%%%%%%%%%%%for weight%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

m = 96.8/2.2046;

%%%%%%%%%%%%%%%%%%%%%%%%%%% for tab%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:100
DLUM(i,1)=120*4/1000*(10^9)/298.379;
DARM(i,1)=20*4/1000*(10^9)/298.379;
end

%%%%%%%%%%%%%%%%%%%%%% for parameter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
theta1=2.6;
theta2=.57;
occ=1;

for i = 1:100
Vo(i,1)=1;
ka(i,1)=1;
kA(i,1)=.82;
Vc(i,1)=1;
Pinit(i,1)=1;
VPT(i,1)=15.5;
MTT(i,1)=48.5;
REPL(i,1)=4;
s(i,1)=.073;
kcl(i,1)=.077*m;
V1(i,1)=8.9*m;
V3(i,1)=8.9*m;
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
kcldha(i,1)=6.8*m;
Q(i,1)=1.4*m;
Varmc(i,1)=5.2*m;
Varmp(i,1)=41.4*m;
Vdha(i,1)=3.7*m;
end
%%%%%%%%%%%%%%%%%%%%%%%%for V2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


V2a = 2.45;
V2b = 8.9;
v2c = 0;
v2e=1;
V2 = V2a.*randn(100,1) + V2b;
for i =1 :1:100
if V2(i,1)<0 || V2(i,1)==0
v2c=v2c+1;
end
end
if v2c >0
v2d = V2a.*randn(v2c,1) + V2b;
for i =1 :1:100
if V2(i,1)<0 || V2(i,1)==0
V2(i,1)=v2d(V2e,1);
V2e=V2e+1;
end
end
end
for i=1:100
    V2(i,1) = V2(i,1)*m;
end
%%%%%%%%%%%%%%%%%%%% term 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
tlen=8;
for i = 1:100
y0(i,:)=[DLUM(i,1)/V1(i,1) 0 0 DARM(i,1)/Vo(i,1) 0 0 0 0 10771 8952.9 7441.4 20685]; 
[result1(i,:),result2(i,:),result3(i,:),result4(i,:),...
    result5(i,:),result6(i,:),result7(i,:),result8(i,:),...
    result9(i,:),result10(i,:),result11(i,:),result12(i,:),result13(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
end



%%%%%%%%%%%%%%%%term 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
for i=1:100
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
end
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 16;
 for i= 1:100
 y0(i,:)=[result1(i,end)+DLUM(i,1)/V1(i,1),result2(i,end),result3(i,end),result4(i,end)+DARM(i,1)/Vo(i,1),result5(i,end),result6(i,end),...
    result7(i,end),result8(i,end),result9(i,end),result10(i,end),result11(i,end),result12(i,end)];
[r21(i,:),r22(i,:),r23(i,:),r24(i,:),...
    r25(i,:),r26(i,:),r27(i,:),r28(i,:),...
    r29(i,:),r210(i,:),r211(i,:),r212(i,:),r213(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% term3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
occ=occ+1;
for i=1:100
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
end
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r21(i,end)+DLUM(i,1)/V1(i,1),r22(i,end),r23(i,end),r24(i,end)+DARM(i,1)/Vo(i,1),r25(i,end),r26(i,end),...
    r27(i,end),r28(i,end),r29(i,end),r210(i,end),r211(i,end),r212(i,end)];
[r31(i,:),r32(i,:),r33(i,:),r34(i,:),...
    r35(i,:),r36(i,:),r37(i,:),r38(i,:),...
    r39(i,:),r310(i,:),r311(i,:),r312(i,:),r313(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end



%%%%%%%%%%%%%%%%%%%term four%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
for i=1:100
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
end
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r31(i,end)+DLUM(i,1)/V1(i,1),r32(i,end),r33(i,end),r34(i,end)+DARM(i,1)/Vo(i,1),r35(i,end),r36(i,end),...
    r37(i,end),r38(i,end),r39(i,end),r310(i,end),r311(i,end),r312(i,end)];
[r41(i,:),r42(i,:),r43(i,:),r44(i,:),...
    r45(i,:),r46(i,:),r47(i,:),r48(i,:),...
    r49(i,:),r410(i,:),r411(i,:),r412(i,:),r413(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end

 
%%%%%%%%%%%%%%%%%%%%% term 5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

occ=occ+1;
for i=1:100
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
end
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r41(i,end)+DLUM(i,1)/V1(i,1),r42(i,end),r43(i,end),r44(i,end)+DARM(i,1)/Vo(i,1),r45(i,end),r46(i,end),...
    r47(i,end),r48(i,end),r49(i,end),r410(i,end),r411(i,end),r412(i,end)];
[r51(i,:),r52(i,:),r53(i,:),r54(i,:),...
    r55(i,:),r56(i,:),r57(i,:),r58(i,:),...
    r59(i,:),r510(i,:),r511(i,:),r512(i,:),r513(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end





%%%%%%%%%%%%%%%%%%%%% term 6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
occ=occ+1;
for i=1:100
kclarm(i,1)=theta1*(1+(theta2*(occ-1)))*m;
end
 p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
 tlen = 12;
 for i= 1:100
 y0(i,:)=[r51(i,end)+DLUM(i,1)/V1(i,1),r52(i,end),r53(i,end),r54(i,end)+DARM(i,1)/Vo(i,1),r55(i,end),r56(i,end),...
    r57(i,end),r58(i,end),r59(i,end),r510(i,end),r511(i,end),r512(i,end)];
[r61(i,:),r62(i,:),r63(i,:),r64(i,:),...
    r65(i,:),r66(i,:),r67(i,:),r68(i,:),...
    r69(i,:),r610(i,:),r611(i,:),r612(i,:),r613(i,:)] = tissue_combinedmain(y0(i,:),p(i,:),tlen);
 end


 
t = 0;
for i = 1:7206
    t(i,1) =  i*0.01;
end

rLUM = cat(2,result2,r22,r32,r42,r52,r62);
rARM1 = cat(2,result5,r25,r35,r45,r55,r65);
rARM2 = cat(2,result6,r26,r36,r46,r56,r66);
rDHA = cat(2,result7,r27,r37,r47,r57,r67);

for i = 1:100
    AUCLUM(i,1) = trapz(t,rLUM(i,:));
    AUCARM(i,1) = trapz(t,rARM1(i,:))+trapz(t,rARM2(i,:));
    AUCDHA(i,1) = trapz(t,rDHA(i,:));
    CtrLUM(i,1) = rLUM(i,end);
    CtrARM(i,1) = rARM1(i,end)+rARM2(i,end);
    CtrDHA(i,1) = rDHA(i,end);
end
    
figure(1)
plot(t,rLUM(50,:))
figure(2)
plot(t,rARM1(50,:)+rARM2(50,:))
hold on
plot(t,rDHA(50,:))

