function [out1,out2,out3,out4,out5,out6,out7,out8,out9,out10,out11,out12,out13] = tissue_combinedmain(x,y,c); 
y0=x;
p=y;

 options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
 [T1,Y1] = ode45(@tissue_combinedeqn,[0:.01:c],y0,options,p);
    
out1 = Y1(:,1);
out1 = out1.';
out2 = Y1(:,2);
out2 = out2.';
out3 = Y1(:,3);
out3 = out3.';
out4 = Y1(:,4);
out4 = out4.';
out5 = Y1(:,5);
out5 = out5.';
out6 = Y1(:,6);
out6 = out6.';
out7 = Y1(:,7);
out7 = out7.';
out8 = Y1(:,8);
out8 = out8.';
out9 = Y1(:,9);
out9 = out9.';
out10 = Y1(:,10);
out10 = out10.';
out11 = Y1(:,11);
out11 = out11.';
out12 = Y1(:,12);
out12 = out12.';
out13 = T1;




