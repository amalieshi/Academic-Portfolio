m=5;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata5.mat LUMdata
save LUMinfo5.mat LUMinfo
save ARMdata5.mat ARMdata
save ARMinfo5.mat ARMinfo
save DHAdata5.mat DHAdata
save DHAinfo5.mat DHAinfo
save parasitedata5.mat parasitedata
save parasitemin5.mat parasitemin

m=10;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata10.mat LUMdata
save LUMinfo10.mat LUMinfo
save ARMdata10.mat ARMdata
save ARMinfo10.mat ARMinfo
save DHAdata10.mat DHAdata
save DHAinfo10.mat DHAinfo
save parasitedata10.mat parasitedata
save parasitemin10.mat parasitemin

m=15;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata15.mat LUMdata
save LUMinfo15.mat LUMinfo
save ARMdata15.mat ARMdata
save ARMinfo15.mat ARMinfo
save DHAdata15.mat DHAdata
save DHAinfo15.mat DHAinfo
save parasitedata15.mat parasitedata
save parasitemin15.mat parasitemin

m=20;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata20.mat LUMdata
save LUMinfo20.mat LUMinfo
save ARMdata20.mat ARMdata
save ARMinfo20.mat ARMinfo
save DHAdata20.mat DHAdata
save DHAinfo20.mat DHAinfo
save parasitedata20.mat parasitedata
save parasitemin20.mat parasitemin

m=25;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata25.mat LUMdata
save LUMinfo25.mat LUMinfo
save ARMdata25.mat ARMdata
save ARMinfo25.mat ARMinfo
save DHAdata25.mat DHAdata
save DHAinfo25.mat DHAinfo
save parasitedata25.mat parasitedata
save parasitemin25.mat parasitemin

m=30;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata30.mat LUMdata
save LUMinfo30.mat LUMinfo
save ARMdata30.mat ARMdata
save ARMinfo30.mat ARMinfo
save DHAdata30.mat DHAdata
save DHAinfo30.mat DHAinfo
save parasitedata30.mat parasitedata
save parasitemin30.mat parasitemin

m=35;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata35.mat LUMdata
save LUMinfo35.mat LUMinfo
save ARMdata35.mat ARMdata
save ARMinfo35.mat ARMinfo
save DHAdata35.mat DHAdata
save DHAinfo35.mat DHAinfo
save parasitedata35.mat parasitedata
save parasitemin35.mat parasitemin

m=40;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata40.mat LUMdata
save LUMinfo40.mat LUMinfo
save ARMdata40.mat ARMdata
save ARMinfo40.mat ARMinfo
save DHAdata40.mat DHAdata
save DHAinfo40.mat DHAinfo
save parasitedata40.mat parasitedata
save parasitemin40.mat parasitemin

m=45;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata45.mat LUMdata
save LUMinfo45.mat LUMinfo
save ARMdata45.mat ARMdata
save ARMinfo45.mat ARMinfo
save DHAdata45.mat DHAdata
save DHAinfo45.mat DHAinfo
save parasitedata45.mat parasitedata
save parasitemin45.mat parasitemin

m=50;
step=0;
z=1;
[LUMinfo,ARMinfo,DHAinfo,parasitemin ,timedata,LUMdata,ARMdata,DHAdata,...
    parasitedata]= pharmafinal_missingdose(m,step,z);
step=0;
z=0;
[LUMinfomiss,ARMinfomiss,DHAinfomiss,parasiteminmiss ,timedatamiss,LUMdatamiss,ARMdatamiss,DHAdatamiss,...
    parasitedatamiss]= pharmafinal_missingdose(m,step,z);
step=1;
z=1;
[LUMinfo1,ARMinfo1,DHAinfo1,parasitemin1,timedata1,LUMdata1,ARMdata1,DHAdata1,...
    parasitedata1]= pharmafinal_missingdose(m,step,z);
step=2;
z=1;
[LUMinfo2,ARMinfo2,DHAinfo2,parasitemin2,timedata2,LUMdata2,ARMdata2,DHAdata2,...
    parasitedata2]= pharmafinal_missingdose(m,step,z);
step=3;
z=1;
[LUMinfo3,ARMinfo3,DHAinfo3,parasitemin3,timedata3,LUMdata3,ARMdata3,DHAdata3,...
    parasitedata3]= pharmafinal_missingdose(m,step,z);
step=4;
z=1;
[LUMinfo4,ARMinfo4,DHAinfo4,parasitemin4,timedata4,LUMdata4,ARMdata4,DHAdata4,...
    parasitedata4]= pharmafinal_missingdose(m,step,z);
step=5;
z=1;
[LUMinfo5,ARMinfo5,DHAinfo5,parasitemin5,timedata5,LUMdata5,ARMdata5,DHAdata5,...
    parasitedata5]= pharmafinal_missingdose(m,step,z);

LUMdata=[timedata LUMdata LUMdatamiss LUMdata1 LUMdata2 LUMdata3 LUMdata4 LUMdata5];
ARMdata=[timedata ARMdata ARMdatamiss ARMdata1 ARMdata2 ARMdata3 ARMdata4 ARMdata5];
DHAdata=[timedata DHAdata DHAdatamiss DHAdata1 DHAdata2 DHAdata3 DHAdata4 DHAdata5];
parasitedata=[timedata parasitedata parasitedatamiss parasitedata1 parasitedata2 parasitedata3 parasitedata4 parasitedata5];
LUMinfo=[LUMinfo ;LUMinfomiss ;LUMinfo1 ;LUMinfo2 ;LUMinfo3 ;LUMinfo4 ;LUMinfo5];
ARMinfo=[ARMinfo ;ARMinfomiss ;ARMinfo1 ;ARMinfo2 ;ARMinfo3 ;ARMinfo4 ;ARMinfo5];
DHAinfo=[DHAinfo ;DHAinfomiss ;DHAinfo1 ;DHAinfo2 ;DHAinfo3 ;DHAinfo4 ;DHAinfo5];
parasitemin=[parasitemin ;parasiteminmiss ;parasitemin1 ;parasitemin2 ;parasitemin3 ;parasitemin4 ;parasitemin5];

save LUMdata50.mat LUMdata
save LUMinfo50.mat LUMinfo
save ARMdata50.mat ARMdata
save ARMinfo50.mat ARMinfo
save DHAdata50.mat DHAdata
save DHAinfo50.mat DHAinfo
save parasitedata50.mat parasitedata
save parasitemin50.mat parasitemin




