function [LUMinfo,ARMinfo,DHAinfo,parasitemin,timedata,LUMdata,...
    ARMdata,DHAdata,parasitedata] = pharmafinal_missingdose(x,y,z);

m=x;
step=y;
Z=z;

if m >= 5 & m <= 14
    tab=1;
elseif m >= 15 & m <= 24
    tab=2;
elseif m >= 25 & m <= 34
    tab=3;
elseif m >=35
    tab=4;
end

DLUM=120*tab/1000*(10^9)/298.379;
DARM=20*tab/1000*(10^9)/298.379;
DLUMmiss=DLUM*Z;
DARMmiss=DARM*Z;
hr=(16/5)*step;

theta1=2.6;
theta2=.57;
occ=1;

kA=.82;
kcl=.077*m;
V1=8.9*m;
V2=8.9*m;
V3=8.9*m;
ka=1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
kcldha=6.8*m;
Q=1.4*m;
Vo=1;
Varmc=5.2*m;
Varmp=41.4*m;
Vdha=3.7*m;
Vc=1;
Pinit=1;
VPT=15.5;
MTT=48.5;
REPL=4;
s=.073;

p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];
y0=[DLUM/V1 0 0 DARM/Vo 0 0 0 0 10771 8952.9 7441.4 20685];

options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
[T1,Y1] = ode45(@tissue_combinedeqn,[0:.01:8+hr],y0,options,p);

if Z==0
    occ=occ-1;
end

if step==5
    y0=[Y1(end,1)+(2*DLUMmiss)/V1,Y1(end,2),Y1(end,3),Y1(end,4)+(2*DARMmiss)/Vo,Y1(end,5),Y1(end,6),...
        Y1(end,7),Y1(end,8),Y1(end,9),Y1(end,10),Y1(end,11),Y1(end,12)];
    occ=occ+1;
    kclarm=theta1*(1+(theta2*(occ-1)))*m;
    p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

    TotalD1_1 = Y1(:,1)*V1;
    TotalD2_1 = Y1(:,2)*V2;
    TotalD3_1 = Y1(:,3)*V3;
    massbalLUM=-TotalD1_1-TotalD2_1-TotalD3_1+DLUM;


    TotalD4_1 = Y1(:,4)*Vo;
    TotalD5_1 = Y1(:,5)*Varmc;
    TotalD6_1 = Y1(:,6)*Varmp;
    TotalD7_1 = Y1(:,7)*Vdha;
    TotalD8_1 = Y1(:,8)*Vc;
    massbalARM=-TotalD4_1-TotalD5_1-TotalD6_1-TotalD7_1-TotalD8_1+DARM;    
else
    y0=[Y1(end,1)+DLUMmiss/V1,Y1(end,2),Y1(end,3),Y1(end,4)+DARMmiss/Vo,Y1(end,5),Y1(end,6),...
        Y1(end,7),Y1(end,8),Y1(end,9),Y1(end,10),Y1(end,11),Y1(end,12)];
    occ=occ+1;
    kclarm=theta1*(1+(theta2*(occ-1)))*m;
    p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

    TotalD1_1 = Y1(:,1)*V1;
    TotalD2_1 = Y1(:,2)*V2;
    TotalD3_1 = Y1(:,3)*V3;
    massbalLUM=-TotalD1_1-TotalD2_1-TotalD3_1+DLUM;


    TotalD4_1 = Y1(:,4)*Vo;
    TotalD5_1 = Y1(:,5)*Varmc;
    TotalD6_1 = Y1(:,6)*Varmp;
    TotalD7_1 = Y1(:,7)*Vdha;
    TotalD8_1 = Y1(:,8)*Vc;
    massbalARM=-TotalD4_1-TotalD5_1-TotalD6_1-TotalD7_1-TotalD8_1+DARM;

    options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
    [T2,Y2] = ode45(@tissue_combinedeqn,[0:.01:16-hr],y0,options,p);

    y0=[Y2(end,1)+DLUM/V1,Y2(end,2),Y2(end,3),Y2(end,4)+DARM/Vo,Y2(end,5),Y2(end,6),...
        Y2(end,7),Y2(end,8),Y2(end,9),Y2(end,10),Y2(end,11),Y2(end,12)];
    occ=occ+1;
    kclarm=theta1*(1+(theta2*(occ-1)))*m;
    p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

    TotalD1_2 = Y2(:,1)*V1;
    TotalD2_2 = Y2(:,2)*V2;
    TotalD3_2 = Y2(:,3)*V3;

    TotalD4_2 = Y2(:,4)*Vo;
    TotalD5_2 = Y2(:,5)*Varmc;
    TotalD6_2 = Y2(:,6)*Varmp;
    TotalD7_2 = Y2(:,7)*Vdha;
    TotalD8_2 = Y2(:,8)*Vc;

    Y1= vertcat(Y1([1:end-1],:),Y2);
    T2=T2+8+hr;
    T1= vertcat(T1([1:end-1]),T2);

    massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_2-TotalD2_2-TotalD3_2+(DLUM*2)));
    massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_2-TotalD5_2-TotalD6_2-TotalD7_2-TotalD8_2+(DARM*2)));
end

options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
[T3,Y3] = ode45(@tissue_combinedeqn,[0:.01:12],y0,options,p);

y0=[Y3(end,1)+DLUM/V1,Y3(end,2),Y3(end,3),Y3(end,4)+DARM/Vo,Y3(end,5),Y3(end,6),...
    Y3(end,7),Y3(end,8),Y3(end,9),Y3(end,10),Y3(end,11),Y3(end,12)];
occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

TotalD1_3 = Y3(:,1)*V1;
TotalD2_3 = Y3(:,2)*V2;
TotalD3_3 = Y3(:,3)*V3;

TotalD4_3 = Y3(:,4)*Vo;
TotalD5_3 = Y3(:,5)*Varmc;
TotalD6_3 = Y3(:,6)*Varmp;
TotalD7_3 = Y3(:,7)*Vdha;
TotalD8_3 = Y3(:,8)*Vc;

Y1= vertcat(Y1([1:end-1],:),Y3);
T3=T3+24;
T1= vertcat(T1([1:end-1]),T3);

massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_3-TotalD2_3-TotalD3_3+(DLUM*3)));
massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_3-TotalD5_3-TotalD6_3-TotalD7_3-TotalD8_3+(DARM*3)));

options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
[T4,Y4] = ode45(@tissue_combinedeqn,[0:.01:12],y0,options,p);

y0=[Y4(end,1)+DLUM/V1,Y4(end,2),Y4(end,3),Y4(end,4)+DARM/Vo,Y4(end,5),Y4(end,6),...
    Y4(end,7),Y4(end,8),Y4(end,9),Y4(end,10),Y4(end,11),Y4(end,12)];
occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

TotalD1_4 = Y4(:,1)*V1;
TotalD2_4 = Y4(:,2)*V2;
TotalD3_4 = Y4(:,3)*V3;

TotalD4_4 = Y4(:,4)*Vo;
TotalD5_4 = Y4(:,5)*Varmc;
TotalD6_4 = Y4(:,6)*Varmp;
TotalD7_4 = Y4(:,7)*Vdha;
TotalD8_4 = Y4(:,8)*Vc;

Y1= vertcat(Y1([1:end-1],:),Y4);
T4=T4+36;
T1= vertcat(T1([1:end-1]),T4);

massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_4-TotalD2_4-TotalD3_4+(DLUM*4)));
massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_4-TotalD5_4-TotalD6_4-TotalD7_4-TotalD8_4+(DARM*4)));

options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
[T5,Y5] = ode45(@tissue_combinedeqn,[0:.01:12],y0,options,p);

y0=[Y5(end,1)+DLUM/V1,Y5(end,2),Y5(end,3),Y5(end,4)+DARM/Vo,Y5(end,5),Y5(end,6),...
    Y5(end,7),Y5(end,8),Y5(end,9),Y5(end,10),Y5(end,11),Y5(end,12)];
occ=occ+1;
kclarm=theta1*(1+(theta2*(occ-1)))*m;
p=[kA,kcl,V1,V2,V3,ka,kclarm,kcldha,Q,Vo,Varmc,Varmp,Vdha,Vc,Pinit,VPT,MTT,REPL,s];

TotalD1_5 = Y5(:,1)*V1;
TotalD2_5 = Y5(:,2)*V2;
TotalD3_5 = Y5(:,3)*V3;

TotalD4_5 = Y5(:,4)*Vo;
TotalD5_5 = Y5(:,5)*Varmc;
TotalD6_5 = Y5(:,6)*Varmp;
TotalD7_5 = Y5(:,7)*Vdha;
TotalD8_5 = Y5(:,8)*Vc;

Y1= vertcat(Y1([1:end-1],:),Y5);
T5=T5+48;
T1= vertcat(T1([1:end-1]),T5);

massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_5-TotalD2_5-TotalD3_5+(DLUM*5)));
massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_5-TotalD5_5-TotalD6_5-TotalD7_5-TotalD8_5+(DARM*5)));

options = odeset('MaxStep',5e-2, 'AbsTol', 1e-5,'RelTol', 1e-5,'InitialStep', 1e-2);
[T6,Y6] = ode45(@tissue_combinedeqn,[0:.01:12],y0,options,p);

TotalD1_6 = Y6(:,1)*V1;
TotalD2_6 = Y6(:,2)*V2;
TotalD3_6 = Y6(:,3)*V3;

TotalD4_6 = Y6(:,4)*Vo;
TotalD5_6 = Y6(:,5)*Varmc;
TotalD6_6 = Y6(:,6)*Varmp;
TotalD7_6 = Y6(:,7)*Vdha;
TotalD8_6 = Y6(:,8)*Vc;

Y1= vertcat(Y1([1:end-1],:),Y6);
T6=T6+60;
T1= vertcat(T1([1:end-1]),T6);

massbalLUM=vertcat(massbalLUM(1:end-1),(-TotalD1_6-TotalD2_6-TotalD3_6+(DLUM*6)));
massbalARM=vertcat(massbalARM(1:end-1),(-TotalD4_6-TotalD5_6-TotalD6_6-TotalD7_6-TotalD8_6+(DARM*6)));

% figure(1)
% plot(T1,Y1(:,2))
% 
% figure(2)
% plot(T1,Y1(:,5)+Y1(:,6))
% hold on
% plot(T1,Y1(:,7))
% 
% figure(3)
% plot(T1,log10(Y1(:,12)))

LUMinfo=[trapz(T1,Y1(:,2)),max(Y1(801:3601,2)),min(Y1(801:3601,2))];
ARMinfo=[trapz(T1,Y1(:,5)+Y1(:,6)),max(Y1(801:3601,5)+Y1(801:3601,6)),min(Y1(801:3601,5)+Y1(801:3601,6))];
DHAinfo=[trapz(T1,Y1(:,7)),max(Y1(801:3601,7)),min(Y1(801:3601,7))];
parasitemin=[min(log(Y1(801:3601,12))),min(log(Y1(:,12)))];
timedata=T1;
LUMdata=Y1(:,2);
ARMdata=Y1(:,5)+Y1(:,6);
DHAdata=Y1(:,7);
parasitedata=log10(Y1(:,12));


% figure(4)
% plot(T1,massbalLUM)
% 
% figure(5)
% plot(T1,massbalARM)

