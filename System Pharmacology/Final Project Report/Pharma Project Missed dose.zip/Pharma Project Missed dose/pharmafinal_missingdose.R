library(shiny)
library(plotly)
library(ggplot2) 
library(R.matlab)
library(gridExtra)
library(reshape2)

Data_frommat <- readMat("LUMinfo.mat",header=T)
df_frommatLUM <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMinfo.mat",header=T)
df_frommatARM <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAinfo.mat",header=T)
df_frommatDHA <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasiteinfo.mat",header=T)
df_frommatparasite <- as.data.frame(Data_frommat) 

g1 <- ggplot(df_frommatLUM,aes(x=LUMdata43.1,y=LUMdata43.2))+ 
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.2,color='Properly Taken'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.3,color='Completly Missed'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.4,color='3.2 hr after'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.5,color='6.4 hr after'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.6,color='9.6 hr after'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.7,color='12.8 hr after'),size=1) +
  geom_line(aes(x=LUMdata43.1,y=LUMdata43.8,color='Double next dose'),size=1) +
  scale_x_continuous("Time (hrs)") + 
  scale_y_continuous("[LUM] (nM)") + 
  scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
  theme(legend.title = element_blank())+
  ggtitle("Concentration of LUM in body after missed dose")

g2 <- ggplot(df_frommatARM,aes(x=ARMdata43.1,y=ARMdata43.2))+ 
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.2,color='Properly Taken'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.3,color='Completly Missed'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.4,color='3.2 hr after'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.5,color='6.4 hr after'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.6,color='9.6 hr after'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.7,color='12.8 hr after'),size=1) +
  geom_line(aes(x=ARMdata43.1,y=ARMdata43.8,color='Double next dose'),size=1) +
  scale_x_continuous("Time (hrs)") + 
  scale_y_continuous("[ARM] (nM)") + 
  scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
  theme(legend.title = element_blank())+
  ggtitle("Concentration of ARM in body after missed dose")

g3 <- ggplot(df_frommatDHA,aes(x=DHAdata43.1,y=DHAdata43.2))+ 
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.2,color='Properly Taken'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.3,color='Completly Missed'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.4,color='3.2 hr after'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.5,color='6.4 hr after'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.6,color='9.6 hr after'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.7,color='12.8 hr after'),size=1) +
  geom_line(aes(x=DHAdata43.1,y=DHAdata43.8,color='Double next dose'),size=1) +
  scale_x_continuous("Time (hrs)") + 
  scale_y_continuous("[DHA] (nM)") + 
  scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
  theme(legend.title = element_blank())+
  ggtitle("Concentration of DHA in body after missed dose")

g4 <- ggplot(df_frommatparasite,aes(x=parasitedata43.1,y=parasitedata43.2))+ 
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.2,color='Properly Taken'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.3,color='Completly Missed'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.4,color='3.2 hr after'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.5,color='6.4 hr after'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.6,color='9.6 hr after'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.7,color='12.8 hr after'),size=1) +
  geom_line(aes(x=parasitedata43.1,y=parasitedata43.8,color='Double next dose'),size=1) +
  scale_x_continuous("Time (hrs)") + 
  scale_y_continuous("[Parasite] (1/uL of blood)") + 
  scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
  theme(legend.title = element_blank())+
  ggtitle("Concentration of LUM in body after missed dose")

plot(g1)
plot(g2)
plot(g3)
plot(g4)



