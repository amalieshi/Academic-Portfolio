rm(list = ls())
cat("\014")

library(shiny)
library(plotly)
library(ggplot2) 
library(R.matlab)
library(gridExtra)
library(reshape2)

de<-data.frame("Properly Taken","Completly Missed","3.2 hr after","6.4 hr after","9.6 hr after","12.8 hr after","Double next dose")

Data_frommat <- readMat("LUMdata5.mat",header=T)
df_frommatLUM5 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata5.mat",header=T)
df_frommatARM5 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata5.mat",header=T)
df_frommatDHA5 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata5.mat",header=T)
df_frommatparasite5 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata10.mat",header=T)
df_frommatLUM10 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata10.mat",header=T)
df_frommatARM10 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata10.mat",header=T)
df_frommatDHA10 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata10.mat",header=T)
df_frommatparasite10 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata15.mat",header=T)
df_frommatLUM15 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata15.mat",header=T)
df_frommatARM15 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata15.mat",header=T)
df_frommatDHA15 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata15.mat",header=T)
df_frommatparasite15 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata20.mat",header=T)
df_frommatLUM20 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata20.mat",header=T)
df_frommatARM20 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata20.mat",header=T)
df_frommatDHA20 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata20.mat",header=T)
df_frommatparasite20 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata25.mat",header=T)
df_frommatLUM25 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata25.mat",header=T)
df_frommatARM25 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata25.mat",header=T)
df_frommatDHA25 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata25.mat",header=T)
df_frommatparasite25 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata30.mat",header=T)
df_frommatLUM30 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata30.mat",header=T)
df_frommatARM30 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata30.mat",header=T)
df_frommatDHA30 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata30.mat",header=T)
df_frommatparasite30 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata35.mat",header=T)
df_frommatLUM35 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata35.mat",header=T)
df_frommatARM35 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata35.mat",header=T)
df_frommatDHA35 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata35.mat",header=T)
df_frommatparasite35 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata40.mat",header=T)
df_frommatLUM40 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata40.mat",header=T)
df_frommatARM40 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata40.mat",header=T)
df_frommatDHA40 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata40.mat",header=T)
df_frommatparasite40 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata45.mat",header=T)
df_frommatLUM45 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata45.mat",header=T)
df_frommatARM45 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata45.mat",header=T)
df_frommatDHA45 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata45.mat",header=T)
df_frommatparasite45 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMdata50.mat",header=T)
df_frommatLUM50 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("ARMdata50.mat",header=T)
df_frommatARM50 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("DHAdata50.mat",header=T)
df_frommatDHA50 <- as.data.frame(Data_frommat) 
Data_frommat <- readMat("parasitedata50.mat",header=T)
df_frommatparasite50 <- as.data.frame(Data_frommat) 

Data_frommat <- readMat("LUMinfo5.mat",header=T)
df_frommatLUMinfo5 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo5)[colnames(df_frommatLUMinfo5)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo5)[colnames(df_frommatLUMinfo5)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo5)[colnames(df_frommatLUMinfo5)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo5.mat",header=T)
df_frommatARMinfo5 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo5)[colnames(df_frommatARMinfo5)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo5)[colnames(df_frommatARMinfo5)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo5)[colnames(df_frommatARMinfo5)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo5.mat",header=T)
df_frommatDHAinfo5 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo5)[colnames(df_frommatDHAinfo5)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo5)[colnames(df_frommatDHAinfo5)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo5)[colnames(df_frommatDHAinfo5)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin5.mat",header=T)
df_frommatparasiteinfo5 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo5)[colnames(df_frommatparasiteinfo5)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo5)[colnames(df_frommatparasiteinfo5)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo10.mat",header=T)
df_frommatLUMinfo10 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo10)[colnames(df_frommatLUMinfo10)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo10)[colnames(df_frommatLUMinfo10)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo10)[colnames(df_frommatLUMinfo10)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo10.mat",header=T)
df_frommatARMinfo10 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo10)[colnames(df_frommatARMinfo10)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo10)[colnames(df_frommatARMinfo10)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo10)[colnames(df_frommatARMinfo10)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo10.mat",header=T)
df_frommatDHAinfo10 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo10)[colnames(df_frommatDHAinfo10)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo10)[colnames(df_frommatDHAinfo10)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo10)[colnames(df_frommatDHAinfo10)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin10.mat",header=T)
df_frommatparasiteinfo10 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo10)[colnames(df_frommatparasiteinfo10)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo10)[colnames(df_frommatparasiteinfo10)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo15.mat",header=T)
df_frommatLUMinfo15 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo15)[colnames(df_frommatLUMinfo15)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo15)[colnames(df_frommatLUMinfo15)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo15)[colnames(df_frommatLUMinfo15)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo15.mat",header=T)
df_frommatARMinfo15 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo15)[colnames(df_frommatARMinfo15)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo15)[colnames(df_frommatARMinfo15)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo15)[colnames(df_frommatARMinfo15)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo15.mat",header=T)
df_frommatDHAinfo15 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo15)[colnames(df_frommatDHAinfo15)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo15)[colnames(df_frommatDHAinfo15)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo15)[colnames(df_frommatDHAinfo15)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin15.mat",header=T)
df_frommatparasiteinfo15 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo15)[colnames(df_frommatparasiteinfo15)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo15)[colnames(df_frommatparasiteinfo15)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo20.mat",header=T)
df_frommatLUMinfo20 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo20)[colnames(df_frommatLUMinfo20)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo20)[colnames(df_frommatLUMinfo20)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo20)[colnames(df_frommatLUMinfo20)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo20.mat",header=T)
df_frommatARMinfo20 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo20)[colnames(df_frommatARMinfo20)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo20)[colnames(df_frommatARMinfo20)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo20)[colnames(df_frommatARMinfo20)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo20.mat",header=T)
df_frommatDHAinfo20 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo20)[colnames(df_frommatDHAinfo20)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo20)[colnames(df_frommatDHAinfo20)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo20)[colnames(df_frommatDHAinfo20)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin20.mat",header=T)
df_frommatparasiteinfo20 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo20)[colnames(df_frommatparasiteinfo20)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo20)[colnames(df_frommatparasiteinfo20)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo25.mat",header=T)
df_frommatLUMinfo25 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo25)[colnames(df_frommatLUMinfo25)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo25)[colnames(df_frommatLUMinfo25)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo25)[colnames(df_frommatLUMinfo25)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo25.mat",header=T)
df_frommatARMinfo25 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo25)[colnames(df_frommatARMinfo25)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo25)[colnames(df_frommatARMinfo25)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo25)[colnames(df_frommatARMinfo25)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo25.mat",header=T)
df_frommatDHAinfo25 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo25)[colnames(df_frommatDHAinfo25)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo25)[colnames(df_frommatDHAinfo25)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo25)[colnames(df_frommatDHAinfo25)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin25.mat",header=T)
df_frommatparasiteinfo25 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo25)[colnames(df_frommatparasiteinfo25)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo25)[colnames(df_frommatparasiteinfo25)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo30.mat",header=T)
df_frommatLUMinfo30 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo30)[colnames(df_frommatLUMinfo30)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo30)[colnames(df_frommatLUMinfo30)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo30)[colnames(df_frommatLUMinfo30)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo30.mat",header=T)
df_frommatARMinfo30 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo30)[colnames(df_frommatARMinfo30)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo30)[colnames(df_frommatARMinfo30)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo30)[colnames(df_frommatARMinfo30)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo30.mat",header=T)
df_frommatDHAinfo30 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo30)[colnames(df_frommatDHAinfo30)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo30)[colnames(df_frommatDHAinfo30)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo30)[colnames(df_frommatDHAinfo30)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin30.mat",header=T)
df_frommatparasiteinfo30 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo30)[colnames(df_frommatparasiteinfo30)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo30)[colnames(df_frommatparasiteinfo30)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo35.mat",header=T)
df_frommatLUMinfo35 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo35)[colnames(df_frommatLUMinfo35)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo35)[colnames(df_frommatLUMinfo35)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo35)[colnames(df_frommatLUMinfo35)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo35.mat",header=T)
df_frommatARMinfo35 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo35)[colnames(df_frommatARMinfo35)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo35)[colnames(df_frommatARMinfo35)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo35)[colnames(df_frommatARMinfo35)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo35.mat",header=T)
df_frommatDHAinfo35 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo35)[colnames(df_frommatDHAinfo35)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo35)[colnames(df_frommatDHAinfo35)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo35)[colnames(df_frommatDHAinfo35)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin35.mat",header=T)
df_frommatparasiteinfo35 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo35)[colnames(df_frommatparasiteinfo35)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo35)[colnames(df_frommatparasiteinfo35)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo40.mat",header=T)
df_frommatLUMinfo40 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo40)[colnames(df_frommatLUMinfo40)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo40)[colnames(df_frommatLUMinfo40)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo40)[colnames(df_frommatLUMinfo40)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo40.mat",header=T)
df_frommatARMinfo40 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo40)[colnames(df_frommatARMinfo40)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo40)[colnames(df_frommatARMinfo40)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo40)[colnames(df_frommatARMinfo40)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo40.mat",header=T)
df_frommatDHAinfo40 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo40)[colnames(df_frommatDHAinfo40)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo40)[colnames(df_frommatDHAinfo40)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo40)[colnames(df_frommatDHAinfo40)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin40.mat",header=T)
df_frommatparasiteinfo40 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo40)[colnames(df_frommatparasiteinfo40)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo40)[colnames(df_frommatparasiteinfo40)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo45.mat",header=T)
df_frommatLUMinfo45 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo45)[colnames(df_frommatLUMinfo45)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo45)[colnames(df_frommatLUMinfo45)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo45)[colnames(df_frommatLUMinfo45)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo45.mat",header=T)
df_frommatARMinfo45 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo45)[colnames(df_frommatARMinfo45)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo45)[colnames(df_frommatARMinfo45)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo45)[colnames(df_frommatARMinfo45)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo45.mat",header=T)
df_frommatDHAinfo45 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo45)[colnames(df_frommatDHAinfo45)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo45)[colnames(df_frommatDHAinfo45)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo45)[colnames(df_frommatDHAinfo45)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin45.mat",header=T)
df_frommatparasiteinfo45 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo45)[colnames(df_frommatparasiteinfo45)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo45)[colnames(df_frommatparasiteinfo45)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"

Data_frommat <- readMat("LUMinfo50.mat",header=T)
df_frommatLUMinfo50 <- as.data.frame(Data_frommat)
colnames(df_frommatLUMinfo50)[colnames(df_frommatLUMinfo50)=="LUMinfo.1"] <- "AUC"
colnames(df_frommatLUMinfo50)[colnames(df_frommatLUMinfo50)=="LUMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatLUMinfo50)[colnames(df_frommatLUMinfo50)=="LUMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("ARMinfo50.mat",header=T)
df_frommatARMinfo50 <- as.data.frame(Data_frommat)
colnames(df_frommatARMinfo50)[colnames(df_frommatARMinfo50)=="ARMinfo.1"] <- "AUC"
colnames(df_frommatARMinfo50)[colnames(df_frommatARMinfo50)=="ARMinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatARMinfo50)[colnames(df_frommatARMinfo50)=="ARMinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("DHAinfo50.mat",header=T)
df_frommatDHAinfo50 <- as.data.frame(Data_frommat)
colnames(df_frommatDHAinfo50)[colnames(df_frommatDHAinfo50)=="DHAinfo.1"] <- "AUC"
colnames(df_frommatDHAinfo50)[colnames(df_frommatDHAinfo50)=="DHAinfo.2"] <- "Cpeak between 8 and 36 hr [nM]"
colnames(df_frommatDHAinfo50)[colnames(df_frommatDHAinfo50)=="DHAinfo.3"] <- "Ctrough between 8 and 36 hr [nM]"
Data_frommat <- readMat("parasitemin50.mat",header=T)
df_frommatparasiteinfo50 <- as.data.frame(Data_frommat)
colnames(df_frommatparasiteinfo50)[colnames(df_frommatparasiteinfo50)=="parasitemin.1"] <- "Ctrough between 8 and 36 hr [log10(1/uL of blood)]"
colnames(df_frommatparasiteinfo50)[colnames(df_frommatparasiteinfo50)=="parasitemin.2"] <- "Ctrough [log10(1/uL of blood)]"


ui <- fluidPage(
  
  # App title ----
  titlePanel("Final Project missed dose"),
 
  wellPanel(
    selectInput("mass","Mass Selection",
                choices=list("5 kg"=0,"10 kg"=1,"15 kg"=2,"20 kg"=3,"25 kg"=4,"30 kg"=5,"35 kg"=6,"40 kg"=7,"45 kg"=8,"50 kg"=9 
                ),selected=0)
  ),
  
   
  fluidRow(
    column(12,
           plotlyOutput("LUM",height=500,width=1000)
    )
  ),
  fluidRow(
  column(12,tableOutput("LUMin"))
  ),
  
  fluidRow(
    column(12,
           plotlyOutput("ARM",height=500,width=1000)
    )
  ),
  
  fluidRow(
    column(12,tableOutput("ARMin"))
  ),
  
  fluidRow(
    column(12,
           plotlyOutput("DHA",height=500,width=1000)
    )
  ),
  
  fluidRow(
    column(12,tableOutput("DHAin"))
  ),
  
  fluidRow(
    column(12,
           plotlyOutput("parasite",height=500,width=1000)
    )
  ),
  
  fluidRow(
    column(12,tableOutput("parasitein"))
  )
  
)

  server <- function(input, output) {
    
    output$LUMin <- renderTable({ 
      f<-input$mass
      if (f==0) x1<-df_frommatLUMinfo5
      else if (f==1) x1<-df_frommatLUMinfo10
      else if (f==2) x1<-df_frommatLUMinfo15
      else if (f==3) x1<-df_frommatLUMinfo20
      else if (f==4) x1<-df_frommatLUMinfo25
      else if (f==5) x1<-df_frommatLUMinfo30
      else if (f==6) x1<-df_frommatLUMinfo35
      else if (f==7) x1<-df_frommatLUMinfo40
      else if (f==8) x1<-df_frommatLUMinfo45
      else if (f==9) x1<-df_frommatLUMinfo50
      x1
    })
    
    output$ARMin <- renderTable({ 
      f<-input$mass
      if (f==0) x2<-df_frommatARMinfo5
      else if (f==1) x2<-df_frommatARMinfo10
      else if (f==2) x2<-df_frommatARMinfo15
      else if (f==3) x2<-df_frommatARMinfo20
      else if (f==4) x2<-df_frommatARMinfo25
      else if (f==5) x2<-df_frommatARMinfo30
      else if (f==6) x2<-df_frommatARMinfo35
      else if (f==7) x2<-df_frommatARMinfo40
      else if (f==8) x2<-df_frommatARMinfo45
      else if (f==9) x2<-df_frommatARMinfo50
      x2
    })
    
    output$DHAin <- renderTable({ 
      f<-input$mass
      if (f==0) x3<-df_frommatDHAinfo5
      else if (f==1) x3<-df_frommatDHAinfo10
      else if (f==2) x3<-df_frommatDHAinfo15
      else if (f==3) x3<-df_frommatDHAinfo20
      else if (f==4) x3<-df_frommatDHAinfo25
      else if (f==5) x3<-df_frommatDHAinfo30
      else if (f==6) x3<-df_frommatDHAinfo35
      else if (f==7) x3<-df_frommatDHAinfo40
      else if (f==8) x3<-df_frommatDHAinfo45
      else if (f==9) x3<-df_frommatDHAinfo50
      x3
    })
    
    output$parasitein <- renderTable({ 
      f<-input$mass
      if (f==0) x4<-df_frommatparasiteinfo5
      else if (f==1) x4<-df_frommatparasiteinfo10
      else if (f==2) x4<-df_frommatparasiteinfo15
      else if (f==3) x4<-df_frommatparasiteinfo20
      else if (f==4) x4<-df_frommatparasiteinfo25
      else if (f==5) x4<-df_frommatparasiteinfo30
      else if (f==6) x4<-df_frommatparasiteinfo35
      else if (f==7) x4<-df_frommatparasiteinfo40
      else if (f==8) x4<-df_frommatparasiteinfo45
      else if (f==9) x4<-df_frommatparasiteinfo50
      x4
    })
    
    output$LUM <- renderPlotly({
      
      g1.5 <- ggplot(df_frommatLUM5,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.10 <- ggplot(df_frommatLUM10,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.15 <- ggplot(df_frommatLUM15,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.20 <- ggplot(df_frommatLUM20,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.25 <- ggplot(df_frommatLUM25,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.30 <- ggplot(df_frommatLUM30,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.35 <- ggplot(df_frommatLUM35,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      
      g1.40 <- ggplot(df_frommatLUM40,aes(x=LUMdata40.1,y=LUMdata40.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.45 <- ggplot(df_frommatLUM45,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      g1.50 <- ggplot(df_frommatLUM50,aes(x=LUMdata.1,y=LUMdata.2))+ 
        geom_line(aes(x=LUMdata.1,y=LUMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=LUMdata.1,y=LUMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[LUM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of LUM in body after missed dose")
      
      f<-input$mass
      if (f==0) g1<-g1.5
      else if (f==1) g1<-g1.10
      else if (f==2) g1<-g1.15
      else if (f==3) g1<-g1.20
      else if (f==4) g1<-g1.25
      else if (f==5) g1<-g1.30
      else if (f==6) g1<-g1.35
      else if (f==7) g1<-g1.40
      else if (f==8) g1<-g1.45
      else if (f==9) g1<-g1.50
      
      P <- ggplotly(g1)
      
    })

    output$ARM <- renderPlotly({
      
      g2.5 <- ggplot(df_frommatARM5,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.10 <- ggplot(df_frommatARM10,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.15 <- ggplot(df_frommatARM15,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.20 <- ggplot(df_frommatARM20,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.25 <- ggplot(df_frommatARM25,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.30 <- ggplot(df_frommatARM30,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.35 <- ggplot(df_frommatARM35,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.40 <- ggplot(df_frommatARM40,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.45 <- ggplot(df_frommatARM45,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      g2.50 <- ggplot(df_frommatARM50,aes(x=ARMdata.1,y=ARMdata.2))+ 
        geom_line(aes(x=ARMdata.1,y=ARMdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=ARMdata.1,y=ARMdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[ARM] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of ARM in body after missed dose")
      
      f<-input$mass
      if (f==0) g2<-g2.5
      else if (f==1) g2<-g2.10
      else if (f==2) g2<-g2.15
      else if (f==3) g2<-g2.20
      else if (f==4) g2<-g2.25
      else if (f==5) g2<-g2.30
      else if (f==6) g2<-g2.35
      else if (f==7) g2<-g2.40
      else if (f==8) g2<-g2.45
      else if (f==9) g2<-g2.50
      
      P <- ggplotly(g2)
    })
    
    output$DHA <- renderPlotly({
      
      g3.5 <- ggplot(df_frommatDHA5,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.10 <- ggplot(df_frommatDHA10,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.15 <- ggplot(df_frommatDHA15,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.20 <- ggplot(df_frommatDHA20,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.20 <- ggplot(df_frommatDHA20,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.25 <- ggplot(df_frommatDHA25,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.30 <- ggplot(df_frommatDHA30,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.35 <- ggplot(df_frommatDHA35,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.40 <- ggplot(df_frommatDHA40,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.45 <- ggplot(df_frommatDHA45,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      g3.50 <- ggplot(df_frommatDHA50,aes(x=DHAdata.1,y=DHAdata.2))+ 
        geom_line(aes(x=DHAdata.1,y=DHAdata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=DHAdata.1,y=DHAdata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[DHA] (nM)") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of DHA in body after missed dose")
      
      f<-input$mass
      if (f==0) g3<-g3.5
      else if (f==1) g3<-g3.10
      else if (f==2) g3<-g3.15
      else if (f==3) g3<-g3.20
      else if (f==4) g3<-g3.25
      else if (f==5) g3<-g3.30
      else if (f==6) g3<-g3.35
      else if (f==7) g3<-g3.40
      else if (f==8) g3<-g3.45
      else if (f==9) g3<-g3.50
      
      P <- ggplotly(g3)
      
      
    })
    
    output$parasite <- renderPlotly({
      
      g4.5 <- ggplot(df_frommatparasite5,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.10 <- ggplot(df_frommatparasite10,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.15 <- ggplot(df_frommatparasite15,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.20 <- ggplot(df_frommatparasite20,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.25 <- ggplot(df_frommatparasite25,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.30 <- ggplot(df_frommatparasite30,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.35 <- ggplot(df_frommatparasite35,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.40 <- ggplot(df_frommatparasite40,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.45 <- ggplot(df_frommatparasite45,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      g4.50 <- ggplot(df_frommatparasite50,aes(x=LUMparasite.1,y=LUMparasite.2))+ 
        geom_line(aes(x=parasitedata.1,y=parasitedata.2,color='Properly Taken'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.3,color='Completly Missed'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.4,color='3.2 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.5,color='6.4 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.6,color='9.6 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.7,color='12.8 hr after'),size=1) +
        geom_line(aes(x=parasitedata.1,y=parasitedata.8,color='Double next dose'),size=1) +
        scale_x_continuous("Time (hrs)") + 
        scale_y_continuous("[parasite] (log10(1/uL of blood))") + 
        scale_color_manual(name='',values=c('Properly Taken'='black','Completly Missed'='blue','3.2 hr after'='red','6.4 hr after'='green','9.6 hr after'='gold','12.8 hr after'='cyan','Double next dose'='orange'))+
        theme(legend.title = element_blank())+
        ggtitle("Concentration of parasite in the blood after missed dose")
      
      f<-input$mass
      if (f==0) g4<-g4.5
      else if (f==1) g4<-g4.10
      else if (f==2) g4<-g4.15
      else if (f==3) g4<-g4.20
      else if (f==4) g4<-g4.25
      else if (f==5) g4<-g4.30
      else if (f==6) g4<-g4.35
      else if (f==7) g4<-g4.40
      else if (f==8) g4<-g4.45
      else if (f==9) g4<-g4.50
      
      P <- ggplotly(g4)
      
      
    })
    
    
  }
  
  shinyApp(ui = ui, server = server)   